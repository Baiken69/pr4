package com.example.Dva;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DvaApplicationTests {

	@Test
	void contextLoads() {
	}

}
